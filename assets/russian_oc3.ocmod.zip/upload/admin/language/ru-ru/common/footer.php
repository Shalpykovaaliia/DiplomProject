<?php
// Text
$_['text_footer'] 	= '<hr><a href="http://www.opencart.com">OpenCart</a> &copy; 2009-' . date('Y') . ' Все права защищены.<br> <a href="https://opencart3x.ru" target="_blank">Модули для OpenCart 3</a>';
$_['text_version'] 	= 'Version %s';

