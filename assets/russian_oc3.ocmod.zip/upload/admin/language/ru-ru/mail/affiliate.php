<?php
// Text
$_['text_approve_subject']      = '%s - Ваш партнерский аккаунт активирован!';
$_['text_approve_welcome']      = 'Добро пожаловать и спасибо за регистрацию на %s!';
$_['text_approve_login']        = 'Ваш аккаунт создан и Вы можете войти используя Ваш E-mail и пароль, посетив наш сайт по адресу:';
$_['text_approve_services']     = 'После входа, Вы сможете получить адрес партнерской ссылки.';
$_['text_approve_thanks']       = 'Спасибо,';
$_['text_transaction_subject']  = '%s - Партнерское вознаграждение.';
$_['text_transaction_received'] = 'Вы получили %s!';
$_['text_transaction_total']    = 'Общая сумма Ваших партнерских вознаграждений %s.';

