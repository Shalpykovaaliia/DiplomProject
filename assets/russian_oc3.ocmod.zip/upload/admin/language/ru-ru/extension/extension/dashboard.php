<?php
// Heading
$_['heading_title']     = 'Панель управления';

// Text
$_['text_success']      = 'Настройки успешно обновлены!';
$_['text_list']         = 'Список';

// Column
$_['column_name']       = 'Название';
$_['column_width']      = 'Ширина';
$_['column_status']     = 'Статус';
$_['column_sort_order'] = 'Порядок сортировки';
$_['column_action']     = 'Действие';

// Error
$_['error_permission']  = 'У Вас нет прав для изменения панели управления!';

